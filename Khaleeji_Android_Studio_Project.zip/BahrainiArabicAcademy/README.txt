KHALEEJI — BAHRAINI ARABIC LEARNING APP
Android Studio project source (not a compiled APK)

WHAT IS INCLUDED IN THIS BUILD
- Android app shell with native Android TextToSpeech bridge
- Arabic script + English-letter reading (transliteration) + English meaning
- Example phrase and English translation
- Hear word, hear example, slow playback, stop playback, speed control
- Daily learning screen, mark learned, progress meter and study-day counter
- Searchable dictionary, 10-question quiz, missed-word review list
- Progress saved locally on the phone using WebView local storage

IMPORTANT VOCABULARY STATUS
This build currently contains the original 50 starter vocabulary entries only. The app is structured to load a larger words.json file and the course target is 3,000 entries (60 days x 50), but the full 3,000-entry Bahraini vocabulary has NOT been populated or verified in this archive. Do not treat this build as a completed 3,000-word course.

AUDIO
The app calls Android's native TextToSpeech engine. It first requests Arabic (Bahrain), then falls back to Arabic (Saudi Arabia), then generic Arabic if the phone does not support the requested locale. Actual voice availability depends on the installed Android TTS engine and downloaded voice data. The synthesized voice may not sound authentically Bahraini; human-recorded Bahraini audio is not included.

BUILD APK
1. Install Android Studio on a computer.
2. Extract this ZIP and open the BahrainiArabicAcademy folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer it to the Android phone and install it. Android may ask you to allow installation from that source.

PHONE AUDIO SETUP
If no audio plays, open Android Settings > Text-to-speech output, select a TTS engine, and install/download an Arabic voice. Reopen the app and test the voice.
